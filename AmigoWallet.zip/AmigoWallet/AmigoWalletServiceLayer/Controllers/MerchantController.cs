﻿using AmigoWalletDAL;
using AmigoWalletDAL.Models;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AmigoWalletServiceLayer.Controllers
{

    [Route("api/[controller]/[action]")]
    [ApiController]
    public class MerchantController : ControllerBase
    {


        private readonly AmigoWalletRepository repository;
        private readonly IMapper mapper;

        public MerchantController(AmigoWalletRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        [HttpGet] // api/Merchant/GetAllMerchantServiceTypes
        public JsonResult GetAllMerchantServiceTypes()
        {
            try
            {
                var tempVar = repository.GetAllMerchantServiceTypes();
                if (tempVar != null)
                {
                    List<Models.MerchantServiceType> returnVal = new List<Models.MerchantServiceType>();
                    foreach (var v in tempVar)
                    {
                        returnVal.Add(mapper.Map<Models.MerchantServiceType>(v));
                    }
                    return new JsonResult(returnVal);
                }
                return new JsonResult(null);
            }
            catch (Exception)
            {
                return new JsonResult(null);
            }
        }


        [HttpGet("{serviceId}")] // api/Merchant/GetMerchantsByServiceId
        public JsonResult GetMerchantsByServiceId(byte serviceId) 
        {
            try
            {
                var tempVar = repository.GetMerchantsByServiceId(serviceId);
                if (tempVar != null)
                {
                    List<Models.PaybillInformation> paybillInformation = new List<Models.PaybillInformation>();
                    foreach (var v in tempVar)
                    {
                        paybillInformation.Add(mapper.Map<Models.PaybillInformation>(v));
                    }
                    return new JsonResult(paybillInformation);
                }
                else
                {
                    return new JsonResult(null);
                }
            }
            catch (Exception)
            {
                return new JsonResult(null);
            }
        }

        [HttpPost] //api/Merchant/PayBill
        public bool PayBill([FromBody] Models.PaybillInformation paybillInformation)
        {
            try
            {
                var tempVar = repository.PayBill(mapper.Map<PaybillInformation>(paybillInformation));
                return tempVar;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
