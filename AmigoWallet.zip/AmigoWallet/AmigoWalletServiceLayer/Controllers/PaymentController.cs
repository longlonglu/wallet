﻿using AmigoWalletDAL;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AmigoWalletServiceLayer.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly AmigoWalletRepository repository;
        private readonly IMapper mapper;

        public PaymentController(AmigoWalletRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        #region HttpGet. This will accept emailId and amount in the url, then save this transaction into DB and return success or error.
        [HttpGet("{emailId}/{amount}")] // api/Payment/TransferMoneyFromCardToBank
        public JsonResult TransferMoneyFromCardToWallet(string emailId, decimal amount) 
        {
            try
            {
                var tempVar = repository.TransferMoneyFromCardToWallet(emailId, amount);
                return new JsonResult(tempVar);
            }
            catch (Exception)
            {
                return new JsonResult("Server Error");
            }
        }
        #endregion
    }
}
