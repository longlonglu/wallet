﻿using AmigoWalletDAL;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmigoWalletServiceLayer.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AmigoWalletController : Controller
    {
        private readonly AmigoWalletRepository rep;
        private readonly IMapper mapper;

        public AmigoWalletController(AmigoWalletRepository rep, IMapper mapper)
        {
            this.rep = rep;
            this.mapper = mapper;
        }
        //Done by Syed
        [HttpGet] //url: api/AmigoWallet/ValidateOTPForTransactions
        public bool ValidateOTPForTransactions(string otpString, string emailId)
        {
            bool status = false;
            status = rep.ValidateOTPForAnyTransaction(otpString, emailId);

            return status;
        }

        //Done by Syed
        [HttpGet] //url: api/AmigoWallet/GenerateOTPForTransactions
        public string GenerateOTPForTransactions(string emailId)
        {
            string otpString = "";
            try
            {
                var otp = rep.GenerateOTPForTransactions(emailId);

                if (otp != null)
                {
                    otpString = otp.Otpvalue;
                }
                else
                {
                    otpString = "No OTP generated";
                }
            }
            catch (Exception)
            {
                otpString = "Error";
            }
            return otpString;
        }

        //Done by Syed
        [HttpGet] //url: api/AmigoWallet/GetWalletBalance
        public decimal GetWalletBalance(string emailId)
        {
            decimal balance = 0;
            try
            {
                balance = rep.GetBalance(emailId);
            }
            catch (Exception)
            {
                balance = -99;
            }

            return balance;
        }

        //Done by Syed
        [HttpGet] //url: api/AmigoWallet/GetAllTransactions
        public JsonResult GetAllTransactions(string emailId)
        {
            List<Models.TransactionDetails> listOfTransactionDetails = new List<Models.TransactionDetails>();
            try
            {
                var transactionDetailsList = rep.GetAllTransactions(emailId);
                if (transactionDetailsList.Any())
                {
                    foreach (var item in transactionDetailsList)
                    {
                        listOfTransactionDetails.Add(new Models.TransactionDetails()
                        {
                            TransactionDate = item.TransactionDate,
                            TransactionInfo = item.TransactionInfo,
                            TransactionType = item.TransactionType,
                            Amount = item.Amount,
                            Status = item.Status
                        });
                    }
                }
            }
            catch (Exception)
            {
                listOfTransactionDetails = null;
            }
            return Json(listOfTransactionDetails);
        }

        [HttpPost]
        public string RegisterUser(Models.User userObj)
        {
            string status = "Error";
            try
            {
                AmigoWalletDAL.Models.User user = new AmigoWalletDAL.Models.User();
                user.EmailId = userObj.EmailId;
                user.MobileNumber = userObj.MobileNumber;
                user.Name = userObj.Name;
                user.Password = userObj.Password;
                user.StatusId = userObj.StatusId;
                user.CreatedTimestamp = new DateTime();
                user.ModifiedTimestamp = new DateTime();

                status = rep.RegisterUser(user);
            }
            catch (Exception e)
            {
                status = "Error";
            }
            return status;
        }

        [HttpGet] // api/AmigoWallet/ValidateUserCredentials
        public bool ValidateUserCredentials(string userEmail, string password)
        {
            var status = false;
            //need to add validation
            AmigoWalletDAL.Models.User user = rep.GetUserInfoForGivenUser(userEmail);
            if (user != null && user.Password == password)
            {
                status = true;
            }

            return status;
        }

        [HttpGet] // api/AmigoWallet/GetAllUsers
        public JsonResult GetAllUsers()
        {
            try
            {
                var tempVar = (rep.GetAllUsers());
                List<Models.User> returnVal = new List<Models.User>();
                if (tempVar != null)
                {
                    foreach (var v in tempVar)
                    {
                        returnVal.Add(mapper.Map<Models.User>(v));
                    }
                }
                return new JsonResult(returnVal);
            }
            catch (Exception)
            {
                return new JsonResult(null);
            }
        }
        [HttpPost]
        public bool BankToWalletTransfer(Models.UserTransaction userTransaction)
        {

            bool status = false;
            AmigoWalletDAL.Models.UserTransaction userTrans = new AmigoWalletDAL.Models.UserTransaction();
            try
            {
                userTrans.Amount = userTransaction.Amount;
                userTrans.EmailId = userTransaction.EmailId;
                userTrans.Info = userTransaction.Info;
                userTrans.PaymentTypeId = userTransaction.PaymentTypeId;
                userTrans.Remarks = userTransaction.Remarks;
                userTrans.IsRedeemed = userTransaction.IsRedeemed;
                userTrans.StatusId = userTransaction.StatusId;
                userTrans.UserTransactionId = userTransaction.UserTransactionId;
                userTrans.TransactionDateTime = userTransaction.TransactionDateTime;
                userTrans.PointsEarned = userTransaction.PointsEarned;

                status = rep.BankToWalletTransfer(userTrans);
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;

        }
        [HttpPost]
        public bool WalletToBankTransfer(Models.UserTransaction userTransaction)
        {

            bool status = false;
            AmigoWalletDAL.Models.UserTransaction userTrans = new AmigoWalletDAL.Models.UserTransaction();
            try
            {
                userTrans.Amount = userTransaction.Amount;
                userTrans.EmailId = userTransaction.EmailId;
                userTrans.Info = userTransaction.Info;
                userTrans.PaymentTypeId = userTransaction.PaymentTypeId;
                userTrans.Remarks = userTransaction.Remarks;
                userTrans.IsRedeemed = userTransaction.IsRedeemed;
                userTrans.StatusId = userTransaction.StatusId;
                userTrans.UserTransactionId = userTransaction.UserTransactionId;
                userTrans.TransactionDateTime = userTransaction.TransactionDateTime;
                userTrans.PointsEarned = userTransaction.PointsEarned;

                status = rep.WalletToBankTransfer(userTrans);
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;

        }
        [HttpPost]
        public bool WalletToWalletTransfer(Models.UserTransaction userTransaction)
        {

            bool status = false;
            AmigoWalletDAL.Models.UserTransaction userTrans = new AmigoWalletDAL.Models.UserTransaction();
            try
            {
                userTrans.Amount = userTransaction.Amount;
                userTrans.EmailId = userTransaction.EmailId;
                userTrans.Info = userTransaction.Info;
                userTrans.PaymentTypeId = userTransaction.PaymentTypeId;
                userTrans.Remarks = userTransaction.Remarks;
                userTrans.IsRedeemed = userTransaction.IsRedeemed;
                userTrans.StatusId = userTransaction.StatusId;
                userTrans.UserTransactionId = userTransaction.UserTransactionId;
                userTrans.TransactionDateTime = userTransaction.TransactionDateTime;
                userTrans.PointsEarned = userTransaction.PointsEarned;

                status = rep.WalletToWalletTransfer(mapper.Map<AmigoWalletDAL.Models.UserTransaction>(userTrans));
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }

        //Mariana's code
         [HttpPut("{emailId}")]
        public bool RedeemPoints(string emailId)
        {
            bool status = false;
            try
            {
                status = rep.RedeemPoints(emailId);
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }

         [HttpGet("{emailId}")]
        public short? GetPointsEarned(string emailId)
        {
            try
            {
                return rep.GetPointsEarned(emailId);
            }
            catch (Exception)
            {
                return null;
            }
        }

        [HttpGet("{emailId}")]
        public JsonResult GetLastTransaction(string emailId)
        {
            try
            {
                return new JsonResult(rep.GetLastTransaction(emailId));
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
