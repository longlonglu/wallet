﻿using AmigoWalletDAL;
using AmigoWalletDAL.Models;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AmigoWalletServiceLayer.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly AmigoWalletRepository repository;
        private readonly IMapper mapper;

        #region This is constructor use to initialize repository and mapper
        public UserController(AmigoWalletRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }
        #endregion

        #region This will accept emailId in the Url. Return an User Object if success, null otherwise.
        // GET api/User/GetUserByEmailId/emailId
        [HttpGet("{emailId}")]
        public JsonResult GetUserByEmailId(string emailId)
        {
            try
            {
                User user = repository.GetUserByEmailId(emailId);
                if (user != null)
                {
                    Models.User returnVal = mapper.Map<Models.User>(user);
                    return new JsonResult(returnVal);
                }
            }
            catch
            {
                return null;
            }
            return null;
        }
        #endregion

        #region This will accept emailId in the Url. Return an Otp Object if success, null otherwise.
        // GET api/User/GenerateOtp/emailId
        [HttpGet("{emailId}")]
        public JsonResult GenerateOtp(string emailId)
        {
            try
            {
                Otp otp = repository.GenerateOtp(emailId);
                if (otp != null)
                {
                    return new JsonResult(otp);
                }
            }
            catch
            {
                return null;
            }
            return null;
        }
        #endregion

        #region This will accept an Otp object, emailId in the Url. Return true if Otp is valid, false otherwise.
        // GET api/User/CheckOtp/emailId
        [HttpPost("{emailId}")]
        public bool CheckOtp([FromBody] Models.Otp incomingOtp, string emailId)
        {
            try
            {
                Otp otp = mapper.Map<Otp>(incomingOtp);
                var tempVar = repository.CheckOtp(otp, emailId);
                if (tempVar)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }

            return false;
        }
        #endregion

        #region This will accept an User Object. Return true if user successfully reseted password, false otherwise.s
        // POST api/User/ResetPassword
        [HttpPost]
        public bool ResetPassword([FromBody] Models.User user)
        {
            try
            {
                var tempVar = repository.ResetPassword(mapper.Map<User>(user));
                return tempVar;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region This will accept a Password Object. Return success if user successfully changed, otherwise, it will return the reason why fail
        [HttpPost] //api/User/ChangePassword
        public JsonResult ChangePassword([FromBody] Models.Password password)
        {
            try
            {
                return new JsonResult(repository.ChangePassword(mapper.Map<Password>(password)));
            }
            catch (Exception)
            {
                return new JsonResult("Server Error");
            }
        }
        #endregion

        #region This will accept emailId in the Url. Return a list of UserCard Objects if success, null otherwise.
        [HttpGet("{emailId}")] // api/User/GetUserCards
        public JsonResult GetUserCards(string emailId)
        {
            try
            {
                List<Models.UserCard> userCards = new List<Models.UserCard>();
                var tempVar = repository.GetUserCards(emailId);
                foreach (var v in tempVar)
                {
                    userCards.Add(mapper.Map<Models.UserCard>(v));
                }
                return new JsonResult(userCards);
            }
            catch (Exception)
            {
                return new JsonResult(new Models.UserCard());
            }
        }
        #endregion

        #region This will accept an UserCard Object. Return success if success, otherwise, it will return the reason why fail
        [HttpPost] // api/User/AddUserCard
        public JsonResult AddUserCard(Models.UserCard userCard)
        {
            try
            {
                var tempVar = repository.AddUserCard(mapper.Map<UserCard>(userCard));
                if (tempVar)
                {
                    return new JsonResult("success");
                }
                else
                {
                    return new JsonResult("Data Access Layer Error");
                }
            }
            catch (Exception)
            {
                return new JsonResult("Server Error");
            }
        }
        #endregion
    }
}
