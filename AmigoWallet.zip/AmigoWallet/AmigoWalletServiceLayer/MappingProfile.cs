﻿using AmigoWalletDAL.Models;
using AutoMapper;

namespace AmigoWalletServiceLayer
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Models.User, User>();
            CreateMap<User, Models.User>();
            CreateMap<Models.Otp, Otp>();
            CreateMap<Otp, Models.Otp>();
            CreateMap<Models.Password, Password>();
            CreateMap<Password, Models.Password>();
            CreateMap<UserTransaction, Models.UserTransaction>();
            CreateMap<Models.UserTransaction, UserTransaction>();
            CreateMap<Models.UserCard, UserCard>();
            CreateMap<UserCard, Models.UserCard>();
            CreateMap<Models.PaybillInformation, PaybillInformation>();
            CreateMap<PaybillInformation, Models.PaybillInformation>();
            CreateMap<MerchantServiceType, Models.MerchantServiceType>();
            CreateMap<Models.MerchantServiceType, MerchantServiceType>();
        }
    }
}
