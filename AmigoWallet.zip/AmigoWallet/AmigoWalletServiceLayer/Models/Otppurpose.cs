﻿using System;
using System.Collections.Generic;

namespace AmigoWalletServiceLayer.Models
{
    public partial class Otppurpose
    {
        public byte OtppurposeId { get; set; }
        public string Otppurpose1 { get; set; }

    }
}
