﻿using System;
using System.Collections.Generic;

namespace AmigoWalletServiceLayer.Models
{
    public partial class Bank
    {
        public byte BankId { get; set; }
        public string BankName { get; set; }
    }
}
