﻿using System;
using System.Collections.Generic;

namespace AmigoWalletServiceLayer.Models
{
    public partial class MerchantServiceType
    {
        public byte ServiceId { get; set; }
        public string ServiceType { get; set; }

    }
}
