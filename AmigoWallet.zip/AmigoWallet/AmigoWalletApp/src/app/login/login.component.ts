import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../amigoWallet-services/user-service/user.service';
import { FormGroup, FormBuilder, FormControl,Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  status: string;
  errorMsg: string;
  loginForm: FormGroup;

  constructor(private _userService: UserService, private formBuilder: FormBuilder) { }


  submitLoginForm(form: FormGroup) {
    if (this.loginForm.valid) {
      this._userService.validateCredentials(form.value.email, form.value.password).subscribe(
        responseLoginStatus => {
          this.status = responseLoginStatus;
          console.log(this.status);
          if (responseLoginStatus == true) {
            sessionStorage.setItem('user', form.value.email);
            sessionStorage.setItem('status', this.status);
            this.errorMsg = "Sucess";
            window.location.reload();
            //add redirect code here to home page
            console.log('Route to homepage');
          } else {
            console.log('Login failed');
            this.errorMsg = "Login Failed";
          }
        },
        responseLoginError => {
          this.errorMsg = responseLoginError;
        },
        () => console.log("SubmitLoginForm method executed successfully")
      );
    } else {
      this.errorMsg = "Login Failed due to invalid data!";
    }
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@!#$%^&*()])[A-Za-z\d@!#$%^&*()].{8,20}$')]],
    });
  }
}
