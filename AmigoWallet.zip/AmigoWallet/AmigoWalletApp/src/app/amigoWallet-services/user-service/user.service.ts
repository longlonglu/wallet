import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
} from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { User } from 'src/app/amigoWallet-interface/user-interface';
import { Otp } from 'src/app/amigoWallet-interface/otp-interface';
import { Password } from 'src/app/amigoWallet-interface/password-interface';
import { UserCard } from 'src/app/amigoWallet-interface/userCard-interface';
import { environment } from "../../../environments/environment"
import { IUser } from '../../amigoWallet-interface/IUser';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private http: HttpClient) { }
  public serverUrl = environment.baseUrl;

  getUserByEmailId(emailId: string): Promise<User> {
    let tempVar = this.http
      .get<User>(this.serverUrl + 'api/User/GetUserByEmailId/' + emailId)
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  generateOtp(emailId: string): Promise<Otp> {
    let tempVar = this.http
      .get<Otp>(this.serverUrl + 'api/User/GenerateOtp/' + emailId)
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  checkOtp(otp: Otp, emailId: string): Promise<boolean> {
    let tempVar = this.http
      .post<boolean>(
        this.serverUrl + 'api/User/CheckOtp/' + emailId,
        otp
      )
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }
  resetPassword(user: User): Promise<boolean> {
    let tempVar = this.http
      .post<boolean>(this.serverUrl + 'api/User/ResetPassword', user)
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  changePassword(password: Password): Promise<string> {
    let tempVar = this.http
      .post<string>(this.serverUrl + 'api/User/ChangePassword', password)
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  addUserCard(userCard: UserCard): Promise<string> {
    let tempVar = this.http
      .post<string>(this.serverUrl + 'api/User/AddUserCard', userCard)
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  getUserCards(emailId: string): Promise<UserCard[]> {
    let tempVar = this.http
      .get<UserCard[]>(
        this.serverUrl + 'api/User/GetUserCards/' + emailId
      )
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  validateCredentials(emailId: string, password: string): Observable<any> {
    var userObj: IUser;
    userObj = { emailId: emailId, password: password, mobileNumber: null, name: null, statusId: 0 };
    const header = new Headers();
    const params = new HttpParams().append('userEmail', emailId).append('password', password);
    return this.http.get('https://localhost:44343/api/AmigoWallet/ValidateUserCredentials', { params: params }).pipe(catchError(this.errorHandler));
  }

  registerUser(emailId: string,
    mobileNumber: number,
    name: string,
    password: string,
    statusId: number) {
    var userObj: IUser;
    userObj = { emailId: emailId, password: password, mobileNumber: mobileNumber, name: name, statusId: statusId };
    return this.http.post<string>('https://localhost:44343/api/AmigoWallet/RegisterUser', userObj).pipe(catchError(this.errorHandler));

  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || 'Server Error');
  }
}
