import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ITransactionDetails } from '../../amigoWallet-interface/transactionDetails';

@Injectable({
  providedIn: 'root'
})
export class WalletService {

  constructor(private http: HttpClient) { }

  viewEWalletBalance(emailId: string): Observable<number> {
    return this.http.get<number>('https://localhost:44343/api/AmigoWallet/GetWalletBalance?emailId=' + emailId)
      .pipe(catchError(this.errorHandler));
  }

  viewUserTransactionDetails(emailId: string): Observable<ITransactionDetails[]> {
    let tempvar = this.http.get<ITransactionDetails[]>('https://localhost:44343/api/AmigoWallet/GetAllTransactions?emailId=' + emailId)
      .pipe(catchError(this.errorHandler));
    return tempvar;
  }

  generateOTPForTransactions(emailId: string): Observable<string> {
    return this.http.get<string>('https://localhost:44343/api/AmigoWallet/GenerateOTPForTransactions?emailId=' + emailId)
      .pipe(catchError(this.errorHandler));
  }

  validateOTPForTransactions(otpString: string, emailId: string): Observable<boolean> {
    return this.http.get<boolean>('https://localhost:44343/api/AmigoWallet/ValidateOTPForTransactions?otpString=' + otpString + '&emailId=' + emailId);
  }
    errorHandler(error: HttpErrorResponse) {
      console.error(error);
      return throwError(error.message || "Server Error");
    }
}
