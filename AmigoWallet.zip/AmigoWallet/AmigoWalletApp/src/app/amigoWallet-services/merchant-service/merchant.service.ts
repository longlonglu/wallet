import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { MerchantServiceType } from 'src/app/amigoWallet-interface/merchantServiceType-interface';
import { PayBillInformation } from 'src/app/amigoWallet-interface/payBillInformation';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class MerchantService {
  constructor(private http: HttpClient) {}
  public serverUrl = environment.baseUrl;

  getAllMerchantServiceTypes(): Promise<MerchantServiceType[]> {
    let tempVar = this.http
      .get<MerchantServiceType[]>(
        this.serverUrl + 'api/Merchant/GetAllMerchantServiceTypes'
      )
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  getMerchantsByServiceId(serviceId: number): Promise<PayBillInformation[]> {
    let tempVar = this.http
      .get<PayBillInformation[]>(
        this.serverUrl + 'api/Merchant/GetMerchantsByServiceId/' + serviceId
      )
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  payBill(payBillInformation: PayBillInformation): Promise<boolean> {
    let tempVar = this.http
      .post<boolean>(
        this.serverUrl + 'api/Merchant/PayBill',
        payBillInformation
      )
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || 'Sericer error');
  }
}
