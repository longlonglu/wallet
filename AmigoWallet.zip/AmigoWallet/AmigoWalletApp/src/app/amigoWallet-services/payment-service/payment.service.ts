import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from "../../../environments/environment"
import { UserTransaction } from '../../amigoWallet-interface/userTransaction';

@Injectable({
  providedIn: 'root',
})
export class PaymentService {
  constructor(private http: HttpClient) { }
  public serverUrl = environment.baseUrl;

  transferMoneyFromCardToWallet(
    emailId: string,
    amount: number
  ): Promise<string> {
    let tempVar = this.http
      .get<string>(
        this.serverUrl + 'api/Payment/TransferMoneyFromCardToWallet/' +
          emailId +
          '/' +
          amount
      )
      .pipe(catchError(this.errorHandler))
      .toPromise();
    return tempVar;
  }

  transferBankToWallet(emailId: string, amount: number): Observable<boolean> {
    var bankToWallet: UserTransaction;
    let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: bankToWallet };
    bankToWallet = { UserTransactionId: 0, EmailId: emailId, Amount: amount, PaymentTypeId: 3, TransactionDatTime: new Date(), Remarks: "", Info: "Bank to Wallet Transfer", StatusId: 1, PointsEarned: 0, IsRedeemed: false }
    console.log(bankToWallet);
    return this.http.post<boolean>('https://localhost:44343/api/AmigoWallet/BankToWalletTransfer', httpOptions).pipe(catchError(this.errorHandler));
  }
  transferWalletToBank(emailId: string, amount: number, remarks: string): Observable<boolean> {
    var walletToBank: UserTransaction;
    let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: walletToBank };
    walletToBank = { UserTransactionId: 0, EmailId: emailId, Amount: amount, PaymentTypeId: 4, TransactionDatTime: new Date(), Remarks: "", Info: "Wallet to Bank", StatusId: 3, PointsEarned: 0, IsRedeemed: false }
    console.log(walletToBank)
    return this.http.post<boolean>('https://localhost:44343/api/AmigoWallet/WalletToBankTransfer', walletToBank).pipe(catchError(this.errorHandler));
  }


  transferWalletToWallet(emailId: string, amount: number, remarks: string): Observable<boolean> {
    var walletToWallet: UserTransaction;
    let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: walletToWallet };
    walletToWallet = { UserTransactionId: 0, EmailId: emailId, Amount: amount, PaymentTypeId: 1, TransactionDatTime: new Date(), Remarks: remarks, Info: "Wallet to Wallet", StatusId: 3, PointsEarned: 0, IsRedeemed: false }
    return this.http.post<boolean>('https://localhost:44343/api/AmigoWallet/WalletToWalletTransfer', walletToWallet).pipe(catchError(this.errorHandler));
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || 'Sericer error');
  }
}
