import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { UserTransaction } from '../../amigoWallet-interface/userTransaction';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

@Injectable({
  providedIn: 'root'
})
export class PointsService {

  transaction: UserTransaction;
  constructor(private http: HttpClient) { }

  getLastTransaction(): Observable<UserTransaction> {
    let tempVar = this.http.get<UserTransaction>('http://localhost:44343/api/AmigoWallet/GetLastTransaction').pipe(catchError(this.errorHandler));
    return tempVar;
  }

  getAllTransactions(): Observable<UserTransaction[]> {
    let tempVar = this.http.get<UserTransaction[]>('http://localhost:44343/api/AmigoWallet/GetAllTransactions').pipe(catchError(this.errorHandler));;
    return tempVar;
  }

  redeemPoints(emailId: string): Observable<any> {
    let tempVar = this.http.put<any>('https://localhost:44343/api/AmigoWallet/RedeemPoints/' + emailId, {}).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  getPointsEarned(emailId: string): Observable<any> {
    let tempVar = this.http.get<any>('https://localhost:44343/api/AmigoWallet/GetPointsEarned/' + emailId).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  errorHandler(error: HttpErrorResponse) {
    console.log(error);
    return throwError(error.message || "Server Error");
  }
}
