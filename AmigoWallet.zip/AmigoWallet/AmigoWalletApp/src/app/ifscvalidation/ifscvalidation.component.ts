import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-ifscvalidation',
  templateUrl: './ifscvalidation.component.html',
  styleUrls: ['./ifscvalidation.component.css']
})
export class IfscvalidationComponent implements OnInit {

  IfscNumber: string;

  constructor(private router: ActivatedRoute, private route: Router) { }

  ngOnInit(): void {
  }

  IfscTransfer(form: NgForm) {
    form.value.IFSCnumber
    console.log(form.value.IFSCnumber)
    this.route.navigate(['/walletToBank', form.value.IFSCnumber])
  }

}
