import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IfscvalidationComponent } from './ifscvalidation.component';

describe('IfscvalidationComponent', () => {
  let component: IfscvalidationComponent;
  let fixture: ComponentFixture<IfscvalidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IfscvalidationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IfscvalidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
