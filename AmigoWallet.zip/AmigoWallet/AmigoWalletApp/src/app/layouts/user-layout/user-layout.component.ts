import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../amigoWallet-services/user-service/user.service';
import { WalletService } from '../../amigoWallet-services/wallet-service/wallet.service';
import { PointsService } from './../../amigoWallet-services/points-service/points.service';
@Component({
  selector: 'app-user-layout',
  templateUrl: './user-layout.component.html',
  styleUrls: ['./user-layout.component.css'],
})
export class UserLayoutComponent implements OnInit {
  public showDifferentComponent: boolean[];
  public showFromCardComponent: boolean = true;
  public showFromBankComponent: boolean = false;
  userBalance: number = 0;
  userName: string = "";
  points: number = 0;
  constructor(private walletService: WalletService, private userService: UserService, private router: Router, private pointsService: PointsService) {
    this.showDifferentComponent = [false, false, false, false, false, false];
  }

  ngOnInit(): void {
    var tempVar = this.walletService.viewEWalletBalance(sessionStorage.getItem('user')).subscribe(
      async (responseDate) => {
        this.userBalance = responseDate;
        await this.userService.getUserByEmailId(sessionStorage.getItem('user')).then(
          (responseDate) => { this.userName = responseDate.name; },
          (responseError) => { console.log(responseError); }
        );
      },
      (responseError) => { console.log(responseError); }
    );

    var points = this.pointsService.getPointsEarned(sessionStorage.getItem('user')).subscribe(
      (responseDate) => { this.points = responseDate; },
      (responseError) => { console.log(responseError); }
    );
    
  }

  changeShowFromCardComponent(): void {
    this.showFromCardComponent = true;
    this.showFromBankComponent = false;
  }

  changeShowFromBankComponent(): void {
    this.showFromCardComponent = false;
    this.showFromBankComponent = true;
  }

  toChangePasswordLayout() {
    this.router.navigate(["/changePassword"]);
  }

  changeComponent(component: number): void {
    this.showDifferentComponent[component] = !this.showDifferentComponent[component];
    for (let i = 0; i < 6; i++) {
      if (i == component) { continue; }
      else { this.showDifferentComponent[i] = false; }
    }
  }
}
