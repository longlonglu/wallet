import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from '../amigoWallet-services/payment-service/payment.service';
import { AddMoneyToWalletComponent } from '../add-money-to-wallet/add-money-to-wallet.component'
import { FormsModule } from '@angular/forms';

import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-bank-transfer',
  templateUrl: './bank-transfer.component.html',
  styleUrls: ['./bank-transfer.component.css']
})
export class BankTransferComponent implements OnInit {



  emailId: string;
  amount: number;
  showDiv1: boolean = true;
  showDiv2: boolean = false;
  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {

    this.amount = this.route.snapshot.params['amount'];
    console.log(this.amount)

  }

  bankTransfer(form: NgForm) {
    this.amount = form.value.amount
  }

  redirect() {
    this.router.navigate(['/'])
  }

  showLogin() {
    if (this.showDiv1 == true) {
      this.showDiv1 = false;
      this.showDiv2 = true;
    }
  }

}
