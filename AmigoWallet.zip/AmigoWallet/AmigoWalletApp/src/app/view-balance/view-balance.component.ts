import { Component, OnInit } from '@angular/core';
import { WalletService } from '../amigoWallet-services/wallet-service/wallet.service';

@Component({
  selector: 'app-view-balance',
  templateUrl: './view-balance.component.html',
  styleUrls: ['./view-balance.component.css']
})
export class ViewBalanceComponent implements OnInit {
  walletBalace: number;
  emailId: string;
  errMsg: string;

  constructor(private _walletService: WalletService) { }

  ngOnInit(): void {
    this.emailId = sessionStorage.getItem('user');
    this.viewWalletBalance();
    
  }
    viewWalletBalance() {
      this._walletService.viewEWalletBalance(this.emailId).subscribe(
        responseEWalletBalance => {
          this.walletBalace = responseEWalletBalance;
          console.log(this.walletBalace);
        },
        responseEWalletBalanceError => {
          this.errMsg = responseEWalletBalanceError;
          this.walletBalace = null;
          console.log(this.errMsg);
        },
        () => console.log("viewWalletBalance method executed successfully")
      );
    }

}
