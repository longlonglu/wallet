import { Component, OnInit } from '@angular/core';
import { AbstractControl, NgForm } from '@angular/forms';
import { UserService } from '../amigoWallet-services/user-service/user.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  status: string;
  errorMsg: string;
  msg: string;
  showDiv: boolean = false;
  registerForm: FormGroup;

  constructor(private _userService: UserService, private formBuilder: FormBuilder) { }

  signUp(form: FormGroup) {
    if (this.registerForm.valid) {
      console.log(form.value.email);
      console.log(form.value.passwordGrp.password);

      this._userService.registerUser(form.value.email, form.value.phoneNumber, form.value.name, form.value.passwordGrp.password, 1).subscribe(
        responseLoginStatus => {
          this.status = responseLoginStatus;
          this.showDiv = true;
          if (this.status == "Sucessful") {
            this.msg = "Registration Successful";
            /*          window.location.reload();*/
            form.reset();
          } else if (this.status == "Duplicate") {
            this.msg = "User already exists! Try Logging in.";
          } else {
            this.msg = this.status + ". Try again with valid data.";
          }
        },
        responseLoginError => {
          this.errorMsg = responseLoginError;
        },
        () => console.log("signUp method successfully executed")
      );
    } else {
      this.msg="Unable to process at this time. Please check the data provided and retry."
    }
  }

  passwordMatcher(control: AbstractControl) {
    var enteredPassword = control.get('password').value;
    var enteredConfirmPassword = control.get('confirmPassword').value;
    //console.log('P: '+enteredPassword);
    //console.log('CP: ' + enteredConfirmPassword);
    if (enteredPassword === enteredConfirmPassword) {
      //console.log('Password matched confirm password');
      return null;
    } else {
      //console.log('NO MATCH');
      return {
        passwordError: {
          message: "Confirm Password did not match with password provided."
        }
      };
    }
  }
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      name: ['', [Validators.required, Validators.pattern('^[A-Za-z ]+$')]],
      email: ['', [Validators.required, Validators.pattern('^[A-Za-z0-9_.]+@[A-Za-z_.]+[A-Za-z]{2,}$')]],
      phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],

      passwordGrp: this.formBuilder.group({
        password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@!#$%^&*()])[A-Za-z\d@!#$%^&*()].{8,20}$')]],
        confirmPassword: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@!#$%^&*()])[A-Za-z\d@!#$%^&*()].{8,20}$')]]
      }, { validator: this.passwordMatcher })
    }
    );
  }

}
