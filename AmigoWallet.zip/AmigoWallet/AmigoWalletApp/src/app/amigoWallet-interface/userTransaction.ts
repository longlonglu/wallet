export interface UserTransaction {
  UserTransactionId: number,
  EmailId: string,
  Amount: number,
  TransactionDatTime: Date,
  PaymentTypeId: number,
  Remarks: string,
  Info: string,
  StatusId: number,
  PointsEarned: number,
  IsRedeemed: boolean

}
