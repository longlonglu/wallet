export interface Password {
  emailId: string;
  oldPassword: string;
  newPassword: string;
}
