export interface ITransactionDetails {
  transactionDate: Date,
  transactionInfo: string,
  transactionType: string,
  amount: number,
  status: string
}
