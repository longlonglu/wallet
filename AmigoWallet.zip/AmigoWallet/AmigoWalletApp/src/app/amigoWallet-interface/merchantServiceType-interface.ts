export interface MerchantServiceType {
  serviceId: number;
  serviceType: string;
}
