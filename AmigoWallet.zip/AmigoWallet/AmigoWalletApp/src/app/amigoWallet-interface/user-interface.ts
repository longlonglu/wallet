export interface User {
  userId: number;
  emailId: string;
  mobileNumber: string;
  name: string;
  password: string;
  statusId: number;
  createdTimestamp: Date;
  modifiedTimestamp: Date;
}
