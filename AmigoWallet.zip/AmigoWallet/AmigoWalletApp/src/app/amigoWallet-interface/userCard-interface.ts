export interface UserCard {
  userCardMappingId?: number;
  emailId: string;
  cardNumber: string;
  bankId?: number;
  expiryDate: Date;
  statusId?: number;
  createdTimestamp?: Date;
  modifiedTimestamp?: Date;
}
