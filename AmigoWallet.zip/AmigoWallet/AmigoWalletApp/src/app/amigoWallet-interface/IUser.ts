export interface IUser {
  emailId: string,
  mobileNumber: number,
  name: string,
  password: string,
  statusId: number
}
