export interface Otp {
  otpid: number;
  otpvalue: string;
  referenceId: string;
  expiryDateTime: Date;
  otppurposeId: number;
  isValid: boolean;
}
