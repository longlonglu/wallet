export interface PayBillInformation {
  merchantEmialid: string;
  discountPercent: number;
  merchantName: string;
  amount: number;
  userEmailId: string;
}
