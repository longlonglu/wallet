import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserTransaction } from '../amigoWallet-interface/userTransaction';
import { UserService } from '../amigoWallet-services/user-service/user.service'
import { PaymentService } from '../amigoWallet-services/payment-service/payment.service'
import { NgForm } from '@angular/forms';
import { WalletService } from '../amigoWallet-services/wallet-service/wallet.service'

@Component({
  selector: 'app-add-money-to-wallet',
  templateUrl: './add-money-to-wallet.component.html',
  styleUrls: ['./add-money-to-wallet.component.css']
})
export class AddMoneyToWalletComponent implements OnInit {

  emailId: string;
  amount: number;
  status: boolean = false;
  showMainContent: Boolean = true;
  errorMsg: string;
  constructor(private router: Router, private _walletService: WalletService, private _amigoServices: PaymentService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.emailId = sessionStorage.getItem('user');

  }

  bankToWalletTransfer(form: NgForm) {
    this._walletService.viewEWalletBalance(this.emailId).subscribe(
      resData => {
        console.log(resData)
        console.log(this.emailId)
        this._amigoServices.transferBankToWallet(this.emailId, form.value.amount).subscribe(
          resData => {
            this.status = resData;
            //this.amount = form.value.amount
            console.log("Transfer successful");
            console.log(form.value.amount)
            console.log(this.amount)
            this.router.navigate(['/bankTransfer', form.value.amount])
          },
          resError => {
            this.errorMsg = resError;
            console.log(this.errorMsg)
          }
        )
      },
      resError => {
        this.errorMsg = resError;
        console.log("Error occured");
      }
    )

   


  }


}
