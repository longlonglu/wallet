import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Password } from '../amigoWallet-interface/password-interface';
import { UserService } from '../amigoWallet-services/user-service/user.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css'],
})
export class ChangePasswordComponent implements OnInit {
  oldPassword: string = '';
  newPassword: string = '';
  comfirmNewPassword: string = '';
  showErrorMessage: boolean = false;
  errorMessage: string = '';
  responseMessage: string = '';
  constructor(private userService: UserService, private router: Router) {}

  keyUpOldPassword(event: any) {
    this.oldPassword = event.target.value;
  }
  keyUpNewPassword(event: any) {
    this.newPassword = event.target.value;
  }
  keyUpComfirmNewPassword(event: any) {
    this.comfirmNewPassword = event.target.value;
    if (this.comfirmNewPassword != this.newPassword) {
      this.errorMessage = 'please enter the same password';
      this.showErrorMessage = true;
    } else {
      this.errorMessage = '';
      this.showErrorMessage = false;
    }
  }

  ngOnInit(): void {}

  async changePassword() {
    var password: Password = {
      emailId: sessionStorage.getItem('user') || '',
      oldPassword: this.oldPassword,
      newPassword: this.newPassword,
    };
    console.log(password);
    const temp = await this.userService.changePassword(password).then(
      (responseData) => {
        console.log(responseData);
        if (responseData == 'success') {
          alert(
            'Password change successfully, your new passowrd is ' +
              this.newPassword
          );
          sessionStorage.removeItem('user');
          this.router.navigate(['']);
        } else {
          this.responseMessage = responseData;
          alert(this.responseMessage);
          this.router.navigate(['changePassword']);
        }
      },
      (responseError) => {
        this.responseMessage = responseError;
        alert(this.responseMessage);
      }
    );
  }
}
