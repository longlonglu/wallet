import { Component, OnInit } from '@angular/core';
import { PointsService } from '../amigoWallet-services/points-service/points.service';

@Component({
  selector: 'app-redeem-points',
  templateUrl: './redeem-points.component.html',
  styleUrls: ['./redeem-points.component.css']
})
export class RedeemPointsComponent implements OnInit {
  emailId: string;
  points: number;
  showMsg: boolean = false;
  msg: string;

  constructor(private _service: PointsService) { }

  ngOnInit() {
    this.emailId = sessionStorage.getItem('user');
    this.getPoints();
    if (this.points == null) {
      this.showMsg = true;
    }
  }

  getPoints() {
    this._service.getPointsEarned(this.emailId).subscribe(
      responsePointsData => {
        this.points = responsePointsData;
        this.showMsg = false;
      },
      responsePointsError => {
        this.points = null;
        this.msg = responsePointsError;
        console.log(this.msg);
      },
      () => console.log("GetPoints() successfully executed!")
    );
  }

  redeemPoints() {
    if (this.points >= 100) {
      //call and update database here
      this._service.redeemPoints(this.emailId).subscribe(
        responsePointsData => {
          this.showMsg = responsePointsData;
          this.msg = "Your points have successfully been redeemed!";
        },
        responsePointsError => {
          this.showMsg = true;
          this.msg = responsePointsError;
          console.log(this.msg);
        },
        () => console.log("RedeemPoints() successfully executed!")
      );
    } else {
      this.showMsg = true;
      this.msg = "Your current points are low, you can't redeem them";
    }
  }
}
