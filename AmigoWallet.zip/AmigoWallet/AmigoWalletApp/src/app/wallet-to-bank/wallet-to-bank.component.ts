import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { PaymentService } from '../amigoWallet-services/payment-service/payment.service';
import { WalletService } from '../amigoWallet-services/wallet-service/wallet.service'

@Component({
  selector: 'app-wallet-to-bank',
  templateUrl: './wallet-to-bank.component.html',
  styleUrls: ['./wallet-to-bank.component.css']
})
export class WalletToBankComponent implements OnInit {

  IFSCnumber: string;
  amount: number;
  emailId: string;
  status: boolean = false;
  showMainContent: Boolean = true;
  errorMsg: string;
  constructor(private router: Router, private _amigoWallet: PaymentService, private _walletService: WalletService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.emailId = sessionStorage.getItem('user');
    this.IFSCnumber = this.route.snapshot.params['IFSCnumber'];

  }

  transferWalletToBank(form: NgForm) {
    this.IFSCnumber = form.value.IFSCnumber
    console.log(form.value.amount)
    console.log(this.emailId)
    this._walletService.viewEWalletBalance(this.emailId).subscribe(
      resData => {
        console.log(resData);
        if (resData > form.value.amount) {
          console.log("YAYYYYY1!!!!")
          this._amigoWallet.transferWalletToBank(this.emailId, form.value.amount, form.value.remarks).subscribe(
            resData => {
              this.status = resData;
              //this.amount = form.value.amount
              console.log("Transfer successful");

              //this.router.navigate(['/bankTransfer', form.value.amount])
            },
            resError => {
              this.errorMsg = resError;
              console.log("Error Occured")
            },
            () => console.log("Transaction successful")
          );

        }
        else {
          alert("Insuffcient funds");
        }
      },
      resError => {
        this.errorMsg = resError
      }
    )


  }

}
