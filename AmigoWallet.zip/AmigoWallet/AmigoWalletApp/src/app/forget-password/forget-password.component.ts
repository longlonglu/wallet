import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Otp } from '../amigoWallet-interface/otp-interface';
import { User } from '../amigoWallet-interface/user-interface';
import { UserService } from '../amigoWallet-services/user-service/user.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css'],
})
export class ForgetPasswordComponent implements OnInit {
  // let user enter email
  showPart1Div: boolean = true;
  //Otp
  showPart2Div: boolean = false;
  //after user entered opt, make this viewable to user.
  showPart3Div: boolean = false;
  emailId: string = '';
  otp: Otp;
  otpValue: string = '';
  showOtpValue: string = '';
  showOtp: boolean = false;
  user: User;
  newPassword?: string;
  confirmNewPassword?: string;
  public errorMessage?: string = '';
  public showErrorMessage: boolean = false;

  constructor(private userService: UserService, private router: Router) {
    this.otp = {
      otpid: 1,
      otpvalue: 'string',
      referenceId: 'string',
      expiryDateTime: new Date(),
      otppurposeId: 1,
      isValid: false,
    };
    this.user = {
      userId: 0,
      emailId: 'string',
      mobileNumber: 'string',
      name: 'string',
      password: 'string',
      statusId: 0,
      createdTimestamp: new Date(),
      modifiedTimestamp: new Date(),
    };
  }

  ngOnInit(): void {}

  async sumbitEmailId() {
    var temp = await this.userService.getUserByEmailId(this.emailId).then(
      async (responseData) => {
        this.user = responseData;
        this.errorMessage = '';
        this.showErrorMessage = false;
        this.showErrorMessage = false;
        this.showPart1Div = false;
        this.showPart2Div = true;
        var otpValue = await this.userService.generateOtp(this.emailId).then(
          async (responseData) => {
            this.showOtpValue = responseData.otpvalue;
            this.showOtp = true;
            this.otp = responseData;
            await timeout(5000);
            this.showOtpValue = '';
            this.showOtp = false;
          },
          (responseError) => {
            this.showErrorMessage = true;
            this.errorMessage = 'Some errors happen please try again';
          }
        );
      },
      (responseError) => {
        this.errorMessage = 'Sorry, We Can not Find This Email';
        this.showErrorMessage = true;
      }
    );
  }
  onKeyEmailId(event: any) {
    this.emailId = event.target.value;
    console.log(this.emailId);
  }
  onKeyOTP(event: any) {
    this.otpValue = event.target.value;
    this.showErrorMessage = false;
  }
  onKeyNewpassword(event: any) {
    this.newPassword = event.target.value;
  }
  onKeyConfirmNewassword(event: any) {
    this.confirmNewPassword = event.target.value;
    if (this.confirmNewPassword != this.newPassword) {
      this.errorMessage = 'please enter the same password';
      this.showErrorMessage = true;
    } else {
      this.errorMessage = '';
      this.showErrorMessage = false;
    }
  }
  async sumbitOTP() {
    this.otp.otpvalue = this.otpValue;
    var temp = await this.userService.checkOtp(this.otp, this.emailId).then(
      (responseData) => {
        if (responseData == true) {
          console.log('Code checked successfully');
          this.showPart1Div = false;
          this.showPart2Div = false;
          this.showPart3Div = true;
          this.showErrorMessage = false;
          this.errorMessage = '';
        } else {
          this.errorMessage = 'Incorrect Code or code has been expierd';
          this.showErrorMessage = true;
        }
      },
      (responseError) => {
        this.errorMessage = 'Incorrect Code or code has been expierd';
        this.showErrorMessage = true;
      }
    );
  }

  async restPassword() {
    this.user.password = this.newPassword || '';
    this.user.modifiedTimestamp = new Date();
    const temp = this.userService.resetPassword(this.user).then(
      (responseData) => {
        if (responseData) {
          alert(
            'Your password has been successfuly changed, your new password is: ' +
              this.user.password
          );
          this.router.navigate(['/home']);
        } else {
          console.log('not changed password');
        }
      },
      (responseError) => {
        this.errorMessage = 'Some errors happen';
        this.showErrorMessage = true;
      }
    );
  }
}

function timeout(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
