import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UserLayoutComponent } from './layouts/user-layout/user-layout.component';
import { GuestLayoutComponent } from './layouts/guest-layout/guest-layout.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { TransferMoneyFromCardComponent } from './transfer-money-from-card/transfer-money-from-card.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ViewTransactionsComponent } from './view-transactions/view-transactions.component';
import { ViewBalanceComponent } from './view-balance/view-balance.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { RegistrationComponent } from './registration/registration.component';
import { PayBillComponent } from './pay-bill/pay-bill.component';
import { AddMoneyToWalletComponent } from './add-money-to-wallet/add-money-to-wallet.component';
import { BankTransferComponent } from './bank-transfer/bank-transfer.component';

import { IfscvalidationComponent } from './ifscvalidation/ifscvalidation.component';
import { WalletToBankComponent } from './wallet-to-bank/wallet-to-bank.component';
import { WalletToWalletComponent } from './wallet-to-wallet/wallet-to-wallet.component';
import { RedeemPointsComponent } from './redeem-points/redeem-points.component';
import { PointsService } from './amigoWallet-services/points-service/points.service';
//http://infosysamigowalletservicelayer.azurewebsites.net/
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserLayoutComponent,
    GuestLayoutComponent,
    ForgetPasswordComponent,
    ChangePasswordComponent,
    TransferMoneyFromCardComponent,
    ViewTransactionsComponent,
    ViewBalanceComponent,
    LoginComponent,
    LogoutComponent,
    RegistrationComponent,
    PayBillComponent,
    AddMoneyToWalletComponent,
    BankTransferComponent,
    IfscvalidationComponent,
    WalletToBankComponent,
    WalletToWalletComponent,
    RedeemPointsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,

  ],
  providers: [PointsService],
  bootstrap: [AppComponent],
})
export class AppModule {}
