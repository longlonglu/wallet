import { Component, OnInit } from '@angular/core';
import { Data } from '@angular/router';
import { ITransactionDetails } from '../amigoWallet-interface/transactionDetails';
import { WalletService } from '../amigoWallet-services/wallet-service/wallet.service';

@Component({
  selector: 'app-view-transactions',
  templateUrl: './view-transactions.component.html',
  styleUrls: ['./view-transactions.component.css']
})
export class ViewTransactionsComponent implements OnInit {
  transactionDetailsList: ITransactionDetails[];
  filteredTransactions: ITransactionDetails[];
  pageOfItems: Array<any>;
  emailId: string;
  startDate: Date;
  endDate: Date;
  showMsgDiv: boolean = false;
  errorMsg: string;
  lastMonth = new Date();

  constructor(private _walletService: WalletService) { }

  ngOnInit(): void {
    this.emailId = sessionStorage.getItem('user');
    this.getAllTransactionDetails();
    
  }
  onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.filteredTransactions = pageOfItems;
  }
  filterByDates(startDate: Date, endDate: Date) {
    console.log(startDate, endDate);
    this.filteredTransactions = this.transactionDetailsList.filter(tran => new Date(tran.transactionDate) >= new Date(startDate) && new Date(tran.transactionDate) <= new Date(endDate));
  }
  oneLastMonthTransactions() {
      
      console.log(this.lastMonth.toLocaleDateString()); // mm/dd/yyyy format
      this.lastMonth.setMonth(this.lastMonth.getMonth() - 1);
      console.log(this.lastMonth);
      this.filteredTransactions = this.transactionDetailsList.filter(tran => new Date(tran.transactionDate) >= new Date(this.lastMonth));

    }
    getAllTransactionDetails() {
      this._walletService.viewUserTransactionDetails(this.emailId).subscribe(
        reponseTransactionDetails => {
          this.transactionDetailsList = reponseTransactionDetails;
          this.showMsgDiv = false;
          console.log("User Transaction Details fetched successfully");
          console.log(this.transactionDetailsList);
          this.oneLastMonthTransactions();
        },
        responseTransactionDetailsError => {
          this.errorMsg = responseTransactionDetailsError;
          this.transactionDetailsList = null;
          this.showMsgDiv = true;
          console.log("Could not fetch User Transaction Details");
        },
        () => console.log("getAllTransactionDetails method executed successfully")
      );
    }

}
