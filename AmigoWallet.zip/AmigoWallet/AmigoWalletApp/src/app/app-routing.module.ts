import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthService } from './amigoWallet-services/auth-service/auth.service';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { HomeComponent } from './home/home.component';
import { TransferMoneyFromCardComponent } from './transfer-money-from-card/transfer-money-from-card.component';
import { BankTransferComponent } from './bank-transfer/bank-transfer.component';
import { WalletToBankComponent } from './wallet-to-bank/wallet-to-bank.component';
const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: '', component: HomeComponent },
  { path: 'forgotPassword', component: ForgetPasswordComponent },
  { path: 'bankTransfer/:amount', component: BankTransferComponent },
  { path: 'walletToBank/:ifscNumber', component: WalletToBankComponent },
  {
    path: 'changePassword',
    component: ChangePasswordComponent,
    canActivate: [AuthService],
  },
  {
    path: 'transferMoneyFromCard',
    component: TransferMoneyFromCardComponent,
    canActivate: [AuthService],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
