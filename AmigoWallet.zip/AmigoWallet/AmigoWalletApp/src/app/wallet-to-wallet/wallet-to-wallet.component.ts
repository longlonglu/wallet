import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from '../amigoWallet-services/payment-service/payment.service';
import { WalletService } from '../amigoWallet-services/wallet-service/wallet.service'


@Component({
  selector: 'app-wallet-to-wallet',
  templateUrl: './wallet-to-wallet.component.html',
  styleUrls: ['./wallet-to-wallet.component.css']
})
export class WalletToWalletComponent implements OnInit {

  emailId: string;
  amount: number;
  remarks: string;
  status: boolean = false;
  errorMsg: string;

  constructor(private _amigoWallet: PaymentService, private _walletService: WalletService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.emailId = sessionStorage.getItem('user');
  }

  transferWalletToWallet(form: NgForm) {
    this._walletService.viewEWalletBalance(this.emailId).subscribe(
      resData => {
        if (resData > form.value.amount) {
          this._amigoWallet.transferWalletToBank(this.emailId, form.value.amount, form.value.remarks).subscribe(
            resData => {
              this.status = resData;
              //this.amount = form.value.amount
              alert("Transfer successful");

              //this.router.navigate(['/bankTransfer', form.value.amount])
            },
            resError => {
              this.errorMsg = resError;
              console.log("Error Occured")
            },
            () => console.log("Transaction successful")
          );
        }
        else {
          alert("Insuffcient funds");
        }
      },
      resError => {
        this.errorMsg = resError
      }
    )

  }
}
