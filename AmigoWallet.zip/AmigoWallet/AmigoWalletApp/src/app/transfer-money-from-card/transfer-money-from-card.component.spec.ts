import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferMoneyFromCardComponent } from './transfer-money-from-card.component';

describe('TransferMoneyFromCardComponent', () => {
  let component: TransferMoneyFromCardComponent;
  let fixture: ComponentFixture<TransferMoneyFromCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferMoneyFromCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferMoneyFromCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
