import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { UserCard } from '../amigoWallet-interface/userCard-interface';
import { PaymentService } from '../amigoWallet-services/payment-service/payment.service';
import { UserService } from '../amigoWallet-services/user-service/user.service';
@Component({
  selector: 'app-transfer-money-from-card',
  templateUrl: './transfer-money-from-card.component.html',
  styleUrls: ['./transfer-money-from-card.component.css'],
})
export class TransferMoneyFromCardComponent implements OnInit {
  cardForm: FormGroup;
  userCards: UserCard[];
  isReadOnly: boolean = false;
  showSaveCard: boolean = true;
  currentDate: Date = new Date();
  showDateError: boolean = false;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService,
    private paymentService: PaymentService
  ) {
    this.cardForm = this.formBuilder.group({
      cardNumber: ['', [Validators.required]],
      month: [''],
      year: [''],
      cvv: [''],
      amount: [''],
      saveCard: [false],
      pin: ['', [Validators.required]],
    });
    this.userCards = [];
  }

  ngOnInit(): void {
    this.getUserCards();
  }

  changeUserCard(value: any) {
    if (value == 'null') {
      this.isReadOnly = false;
      this.showSaveCard = true;
      return;
    }
    var userCard;
    for (let i = 0; i < this.userCards.length; i++) {
      if (this.userCards[i].cardNumber == value) {
        userCard = this.userCards[i];
        break;
      }
    }
    var tempDate = userCard?.expiryDate + '';
    var year = tempDate.substring(2, 4);
    var month = tempDate.substring(5, 7);
    this.cardForm = this.formBuilder.group({
      cardNumber: [userCard?.cardNumber],
      month: [month],
      year: [year],
      cvv: [''],
      amount: [''],
      saveCard: [false],
      pin: [''],
    });
    this.isReadOnly = true;
    this.showSaveCard = false;
  }
  async getUserCards() {
    await this.userService
      .getUserCards(sessionStorage.getItem('user') || '')
      .then(
        (responseData) => {
          this.userCards = responseData;
        },
        (responseError) => {
          alert(responseError);
        }
      );
  }

  async submitForm(form: FormGroup) {
    let dateString =
      '20' + form.value.year + '-' + form.value.month + '-01T00:00:00';
    let expiry = new Date(dateString);
    if (form.value.saveCard) {
      var card: UserCard = {
        emailId: sessionStorage.getItem('user') || '',
        cardNumber: form.value.cardNumber,
        expiryDate: expiry,
      };
      await this.userService.addUserCard(card).then(
        (responseData) => {
          alert('Added card to your wallet');
        },
        (responseError) => {
          console.log(responseError);
          return;
        }
      );
    }
    await this.paymentService
      .transferMoneyFromCardToWallet(
        sessionStorage.getItem('user') || '',
        form.value.amount
      )
      .then(
        (responseData) => {
          alert('Added money to your wallet');
          window.location.reload();
        },
        (responseError) => {
          alert('Some errors');
        }
      );
  }

  async addUserCard(card: UserCard) {
    await this.userService.addUserCard(card).then(
      (responseData) => {
        console.log(responseData);
      },
      (responseError) => {
        console.log(responseError);
      }
    );
  }

  keyupYear(event: any) {
    this.checkDate();
  }
  keyupMonth(event: any) {
    this.checkDate();
  }
  checkDate(): boolean {
    let dateString =
      '20' +
      this.cardForm.value.year +
      '-' +
      this.cardForm.value.month +
      '-01T00:00:00';
    let expiry = new Date(dateString);
    var currentDate = new Date();
    if (expiry.toString() !== 'Invalid Date' && expiry > currentDate) {
      this.showDateError = false;
      console.log(expiry);
      return true;
    } else {
      this.showDateError = true;
      return false;
    }
  }
}
