import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MerchantServiceType } from '../amigoWallet-interface/merchantServiceType-interface';
import { PayBillInformation } from '../amigoWallet-interface/payBillInformation';
import { MerchantService } from '../amigoWallet-services/merchant-service/merchant.service';
import { WalletService } from '../amigoWallet-services/wallet-service/wallet.service';

@Component({
  selector: 'app-pay-bill',
  templateUrl: './pay-bill.component.html',
  styleUrls: ['./pay-bill.component.css'],
})
export class PayBillComponent implements OnInit {
  public serviceTypes: MerchantServiceType[] = [];
  public merchantList: PayBillInformation[] = [];
  public merchant: PayBillInformation;
  public amount: number = 0;
  constructor(
    private router: Router,
    private merchantService: MerchantService,
    private walletService: WalletService
  ) {
    this.merchant = {
      merchantEmialid: '',
      discountPercent: 0,
      merchantName: '',
      amount: 0,
      userEmailId: '',
    };
  }

  ngOnInit(): void {
    this.getAllMerchantServiceTypes();
  }
  changeServiceType(value: any) {
    if (value) {
      this.getMerchantsByServiceId(value);
    } else {
      this.merchantList = [];
    }
  }
  changeMerchant(value: any) {
    for (let i = 0; i < this.merchantList.length; i++) {
      if (this.merchantList[i].merchantEmialid == value) {
        this.merchant = this.merchantList[i];
        break;
      }
    }
  }
  onKeyAmount(event: any) {
    this.amount = event.target.value;
  }
  async getAllMerchantServiceTypes() {
    await this.merchantService.getAllMerchantServiceTypes().then(
      (responseData) => {
        this.serviceTypes = responseData;
        
      },
      (responseError) => {
        console.log('error');
      }
    );
  }

  async getMerchantsByServiceId(serviceId: number) {
    await this.merchantService.getMerchantsByServiceId(serviceId).then(
      (responseData) => {
        this.merchantList = responseData;
      },
      (responseError) => {
        console.log('error');
      }
    );
  }

  async payBill() {
    var emailId = sessionStorage.getItem('user');
    var amount = Number(this.amount);
    this.merchant.userEmailId = emailId || '';
    this.merchant.amount = amount;
    this.walletService.viewEWalletBalance(emailId).subscribe(
      async (responseDate) => {
        if (this.amount < responseDate) {
          await this.merchantService.payBill(this.merchant).then(
            (responseData) => {
              if (responseData != null) {
                alert("Payment made successfully");
                window.location.reload();
              } else {
                alert("Error");
              }
            },
            (responseError) => {
              console.log('error');
            }
          );
        } else {
          alert("Insuffient balance");
          return;
        }
      }
    )
  }
}
