﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoWalletDAL.Models
{
    public class TransactionDetails
    {
        public DateTime TransactionDate { get; set; }
        public string TransactionInfo { get; set; }
        public bool PaymentType1 { get; set; }
        public string TransactionType { get; set; }
        public decimal Amount { get; set; }
        public string Status { get; set; }
    }
}
