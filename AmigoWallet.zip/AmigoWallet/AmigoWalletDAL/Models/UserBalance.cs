﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoWalletDAL.Models
{
    public class UserBalance
    {
        public bool PaymentType1 { get; set; }
        public decimal Amount { get; set; }
    }
}
