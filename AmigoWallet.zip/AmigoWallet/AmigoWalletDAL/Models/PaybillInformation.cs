﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoWalletDAL.Models
{
    public class PaybillInformation
    {
        public string MerchantEmialid { get; set; }
        public double? DiscountPercent { get; set; }
        public string MerchantName { get; set; }
        public double? Amount { get; set; }
        public string? UserEmailId { get; set; }

    }
}
