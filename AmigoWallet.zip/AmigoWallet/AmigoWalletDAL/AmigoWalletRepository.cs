﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using AmigoWalletDAL.Models;
using System.Threading;

namespace AmigoWalletDAL
{
     
    public class AmigoWalletRepository
    {
        private readonly MAR21USBATCH1MSAGROUP3DBContext context;

        public AmigoWalletRepository(MAR21USBATCH1MSAGROUP3DBContext context)
        {
            this.context = context;
        }


        public string RegisterUser(User user)
        {
            try
            {
                User u = GetUserInfoForGivenUser(user.EmailId);
                if (u == null)
                {
                    context.User.Add(user);
                    context.SaveChanges();
                    return "Sucessful";
                }
                else
                {
                    return "Duplicate";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "Error";
            }
        }

        public User GetUserInfoForGivenUser(string emailId)
        {
            User usr = null;
            try
            {
                usr = context.User.Where(u => u.EmailId == emailId).First();

            }
            catch (Exception)
            {

                usr = null;
            }
            return usr;
        }



        //Done By Syed - Inspired by Longlong's CheckOtp method
        public bool ValidateOTPForAnyTransaction(string otpString, string emailId) 
        {
            bool status = false;
            try
            {
                Otp otp = context.Otp.Where(o => o.Otpvalue == otpString).FirstOrDefault();
                if (otp != null && otp.ExpiryDateTime > DateTime.Now && otp.ReferenceId == emailId) {
                   
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }

            return status;
        }

        //Done By Syed, referenced from Longlong's GenerateOTP method
        public Otp GenerateOTPForTransactions(string emailId) 
        {
            DateTime otpGenerationTime = DateTime.Now;
            DateTime expiryTime = otpGenerationTime.AddMinutes(15);
            Random generator = new Random();
            int otpValue = generator.Next(100000, 999999);
            Otp otpObj = new Otp()
            {
                Otpid = 0,
                Otpvalue = otpValue.ToString(),
                ReferenceId = emailId,
                ExpiryDateTime = expiryTime,
                OtppurposeId = 2,
                IsValid = true
            };
            try
            {
                context.Otp.Add(otpObj);
                context.SaveChanges();
                var thread = new Thread(() =>
                {
                    MakeOtpToNotValid(otpObj, 900000);
                })
                {
                    IsBackground = true
                };
                thread.Start();
            }
            catch (Exception)
            {
                otpObj = null;
            }
            return otpObj;
        }


        public decimal GetBalance(string emailId)
        {
            decimal balance = 0;
            List<UserBalance> transList = new List<UserBalance>();
            try
            {
                transList = (from u in context.UserTransaction join p in context.PaymentType
                             on u.PaymentTypeId equals p.PaymentTypeId 
                             where u.EmailId == emailId
                             select new UserBalance { Amount = u.Amount, PaymentType1 = p.PaymentType1 } ).ToList();
                foreach (var item in transList)
                {
                    if (item.PaymentType1 == true) {
                        balance += item.Amount;
                    }
                    else if (item.PaymentType1 == false)
                    {
                        balance -= item.Amount;
                    }
                }
            }
            catch (Exception)
            {
                balance = -99;
                transList = null;
            }

            return balance;
        }

        public List<TransactionDetails> GetAllTransactions(string emailId)
        {
            List<TransactionDetails> transactions = new List<TransactionDetails>();
            try
            {
                //transactions = context.UserTransaction.Where(u => u.EmailId == emailId).ToList();
                transactions = (from u in context.UserTransaction
                                join p in context.PaymentType
                                on u.PaymentTypeId equals p.PaymentTypeId
                                where u.EmailId == emailId
                                join s in context.Status
                                on u.StatusId equals s.StatusId
                                select new TransactionDetails { TransactionDate = u.TransactionDateTime, TransactionInfo = u.Info, PaymentType1 = p.PaymentType1, Amount = u.Amount, Status = s.StatusValue}).ToList();
                foreach (var item in transactions)
                {
                    if (item.PaymentType1 == true) {
                        item.TransactionType = "Credit";
                    }
                    else if (item.PaymentType1 == false)
                    {
                        item.TransactionType = "Debit";
                    }
                }
            }
            catch (Exception)
            {
                transactions = null;
            }
            return transactions;
        }

        public List<User> tempTest()
        {
            return ((from u in context.User
                     select u).ToList());
        }


        #region This will accept an emailId. Return such User Object if db has it, null otherwise
        public User GetUserByEmailId(string emailId)
        {
            try
            {
                User tempVar = context.User.Where(u => u.EmailId == emailId).FirstOrDefault();
                return tempVar;
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        public List<User> GetAllUsers()
        {
            try
            {
                List<User> users = (from u in context.User
                                    select u).ToList();
                return users;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public void MakeOtpToNotValid(Otp otp, int time)
        {
            try
            {
                Thread.Sleep(time);
                otp.IsValid = false;
                using (var newContext = new MAR21USBATCH1MSAGROUP3DBContext())
                {
                    newContext.Otp.Update(otp);
                    newContext.SaveChanges();
                }
            }
            catch (Exception)
            {

            }
        }

        #region This will accept an emailId, then generate an Otp Object and save into db. Return such Otp if success, null otherwise.
        public Otp GenerateOtp(string emailId)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                DateTime expiryDate = dateTime.AddMinutes(5.0);
                Otp otp = new Otp()
                {
                    Otpid = 0,
                    Otpvalue = expiryDate.ToString("HHmmss"),
                    ReferenceId = emailId,
                    ExpiryDateTime = expiryDate,
                    OtppurposeId = 3,
                    IsValid = true
                };
                using (var newContext = new MAR21USBATCH1MSAGROUP3DBContext())
                {
                    newContext.Otp.Add(otp);
                    newContext.SaveChanges();
                }
                var thread = new Thread(() =>
                {
                    MakeOtpToNotValid(otp, 50000);
                })
                {
                    IsBackground = true
                };
                thread.Start();
                return otp;
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion


        #region This will accept an Otp object and emailID, then check such Otp is valid or not in db. Return true is valid, false otherwise
        public bool CheckOtp(Otp otp, string emailId)
        {
            try
            {
                Otp dbOtp = context.Otp.Find(otp.Otpid);
                if (dbOtp != null)
                {
                    if (dbOtp.ReferenceId.Equals(emailId) && dbOtp.ExpiryDateTime > DateTime.Now && otp.Otpvalue.Equals(dbOtp.Otpvalue))
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region This will accept an User Object, then update such User Object's password in db. Return true is success, false otherwise.
        public bool ResetPassword(User user)
        {
            try
            {
                User temp = (from u in context.User
                             where u.UserId == user.UserId
                             select u).FirstOrDefault();
                if (temp != null)
                {
                    using (var newContext = new MAR21USBATCH1MSAGROUP3DBContext())
                    {
                        temp.Password = user.Password;
                        newContext.User.Update(temp);
                        newContext.SaveChanges();
                    }
                    return true;

                }

                return false;

            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region This will accept a Password Object, then check some conditions. Return success if success, return old password is not correct  or not such user or error otherwise.
        public string ChangePassword(Password password)
        {
            try
            {
                User user = context.User.Where(x => x.EmailId == password.EmailId).FirstOrDefault();
                if (user != null)
                {
                    if (user.Password.Equals(password.OldPassword))
                    {
                        if (user.Password.Equals(password.NewPassword))
                        {
                            return "New password can not be the same with old password";
                        }
                        else
                        {
                            user.Password = password.NewPassword;
                            using (var newContext = new MAR21USBATCH1MSAGROUP3DBContext())
                            {
                                newContext.User.Update(user);
                                newContext.SaveChanges();
                            }
                            return "success";
                        }
                    }
                    else
                    {
                        return "Old Password Is Not Correct";
                    }
                }
                else
                {
                    return "No Such User";
                }
            }
            catch (Exception)
            {
                return "Server Error";
            }
        }
        #endregion

        #region This will accept an emailId and amount, then generate an UserTransaction Object and save into db. Return success or error
        public string TransferMoneyFromCardToWallet(string emailId, decimal amount)
        {
            try
            {
                UserTransaction userTransaction = new UserTransaction()
                {
                    UserTransactionId = 0,
                    EmailId = emailId,
                    Amount = amount,
                    TransactionDateTime = DateTime.Now,
                    PaymentTypeId = 3, 
                    Remarks = "Nothing to show",
                    Info = "Transfer money from card to wallet",
                    StatusId = 1,
                    PointsEarned = Convert.ToInt16(GetLastTransaction(emailId).PointsEarned + Math.Ceiling(amount)),
                    IsRedeemed = false
                };
                using (var newContext = new MAR21USBATCH1MSAGROUP3DBContext())
                {
                    newContext.UserTransaction.Add(userTransaction);
                    newContext.SaveChanges();
                }
                return "success";
            }
            catch (Exception)
            {
                return "Data Access Layer Erros";
            }
        }
        #endregion

        #region This will accept an emailId. Return a list of UserCard Objects if success, null otherwise.
        public List<UserCard> GetUserCards(string emailId)
        {
            try
            {
                List<UserCard> userCards = context.UserCard.Where(x => x.EmailId == emailId).ToList();
                if (userCards != null)
                {
                    return userCards;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        #region This will accept an UserCard Object, then store into db. Return true if success, false otherwise.
        public bool AddUserCard(UserCard userCard)
        {
            try
            {
                userCard.BankId = 1;
                userCard.StatusId = 1;
                userCard.CreatedTimestamp = DateTime.Now;
                using (var newContext = new MAR21USBATCH1MSAGROUP3DBContext())
                {
                    newContext.UserCard.Add(userCard);
                    newContext.SaveChanges();
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        public List<MerchantServiceType> GetAllMerchantServiceTypes()
        {
            try
            {
                List<MerchantServiceType> merchantServiceTypes = (from mst in context.MerchantServiceType
                                                                  select mst).ToList();
                return merchantServiceTypes;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<PaybillInformation> GetMerchantsByServiceId(byte serviceId)
        {
            try
            {
                var tempVar = (from msm in context.MerchantServiceMapping
                               from m in context.Merchant
                               where msm.ServiceId == serviceId && m.EmailId == msm.EmailId
                               select new
                               {
                                   MerchantEmialid = msm.EmailId,
                                   DiscountPercent = msm.DiscountPercent,
                                   MerchantName = m.Name
                               }).ToList();

                if (tempVar != null)
                {
                    List<PaybillInformation> paybillInformation = new List<PaybillInformation>();
                    foreach (var v in tempVar)
                    {
                        paybillInformation.Add(new PaybillInformation()
                        {
                            MerchantEmialid = v.MerchantEmialid,
                            DiscountPercent = (double?)v.DiscountPercent,
                            MerchantName = v.MerchantName
                        });
                    }
                    return paybillInformation;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }

        }

        public bool PayBill(PaybillInformation paybillInformation)
        {
            try
            {
                UserTransaction userTransaction = new UserTransaction()
                {
                    UserTransactionId = 0,
                    EmailId = paybillInformation.UserEmailId,
                    Amount = (decimal)paybillInformation.Amount,
                    TransactionDateTime = DateTime.Now,
                    PaymentTypeId = 5,
                    Remarks = "Nothing to show",
                    Info = "Transfer money from wallet to merchant",
                    StatusId = 1,
                    PointsEarned = Convert.ToInt16(GetLastTransaction(paybillInformation.UserEmailId).PointsEarned + Math.Ceiling((decimal)paybillInformation.Amount)),
                    IsRedeemed = false
                };

                MerchantTransaction merchantTransaction = new MerchantTransaction()
                {
                    TransactionId = 0,
                    EmailId = paybillInformation.MerchantEmialid,
                    Amount = (decimal)paybillInformation.Amount,
                    TransactionDateTime = DateTime.Now,
                    PaymentTypeId = 5,
                    Remarks = "Nothing to show",
                    Info = "Recive money form user wallet",
                    StatusId = 1
                };

                using (var newContext = new MAR21USBATCH1MSAGROUP3DBContext())
                {
                    newContext.UserTransaction.Add(userTransaction);
                    newContext.MerchantTransaction.Add(merchantTransaction);
                    newContext.SaveChanges();
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public bool BankToWalletTransfer(UserTransaction userTransaction)
        {
            bool status = false;
            try
            {
                context.UserTransaction.Add(userTransaction);
                context.SaveChanges();
                status = true;
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }

        public bool WalletToBankTransfer(UserTransaction userTransaction)
        {
            bool status = false;
            try
            {
                using (var newContext = new MAR21USBATCH1MSAGROUP3DBContext())
                {
                    newContext.UserTransaction.Add(userTransaction);
                    newContext.SaveChanges();
                }
                status = true;
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }
        public bool WalletToWalletTransfer(UserTransaction userTransaction)
        {
            bool status = false;
            try
            {
                using (var newContext = new MAR21USBATCH1MSAGROUP3DBContext())
                {
                    newContext.UserTransaction.Add(userTransaction);
                    newContext.SaveChanges();
                }
                status = true;
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }

        //Mariana's code
        public bool RedeemPoints(string emailId)
        {
            bool status = false;
            UserTransaction userTrans = null;
            try
            {
                userTrans = GetLastTransaction(emailId);
                if (userTrans != null)
                {
                    var pointsRedeemed = Convert.ToInt16(userTrans.PointsEarned * 0.10);
                    userTrans.Amount = userTrans.Amount + pointsRedeemed;
                    userTrans.PointsEarned = 0;
                    userTrans.IsRedeemed = true;
                    context.UserTransaction.Update(userTrans);
                    context.SaveChanges();
                    status = true;
                } else
                {
                    status = false;
                }
            } 
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

         public UserTransaction GetLastTransaction(string emailId)
        {
            UserTransaction userTransaction = new UserTransaction();
            try
            {
                userTransaction = context.UserTransaction.Where(x => x.EmailId == emailId).OrderByDescending(x => x.UserTransactionId)
                       .FirstOrDefault();
                return userTransaction;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public short? GetPointsEarned(string emailId)
        {
            UserTransaction userTransaction = new UserTransaction();
            try
            {
                userTransaction = context.UserTransaction.Where(x => x.EmailId == emailId).OrderByDescending(x => x.UserTransactionId)
                       .FirstOrDefault();
                return userTransaction.PointsEarned;
            }
            catch (Exception e)
            {

                return null;
            }
        }

    }
}
